# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Looper::Application.config.secret_token = '322aab34d3a95809e0a0ebdc5cd8a8caf8f85a981d0a09001baf93e16c48178e09b4f968e5c6a011635fc33e5ad7a69252a2384f22873242486217692298aa4e'
